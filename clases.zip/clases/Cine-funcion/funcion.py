class Funcion():
    def __init__(self,pelicula,cine,duracion,costo,hora_inicio):
        self.pelicula=pelicula
        self.cine= cine
        self.duracion=duracion
        self.costo= costo
        self.hora_inicio= hora_inicio
    def trasladar(self):
        pass
    def getEmpresa_autos(self):
        return self.Empresa_autos
    def setVelocidadmax(self,velocidadmax):
        self.velocidadmax +=velocidadmax