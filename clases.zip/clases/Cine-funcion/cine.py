class Cine():
    def __init__(self,nombre,propietario,organizacion,ingresos,oficina_central):
        self.nombre=nombre
        self.propietario= propietario
        self.organizacion=organizacion
        self.ingresos= ingresos
        self.oficina_central= oficina_central
    def vender(self):
        pass
    def getPropietario(self):
        return self.propietario
    def setIngresos(self,ingresos):
        self.ingresos +=ingresos