class Auto():
    def __init__(self,diseno,empresa_autos,motor,velocidadmax,aceleracion):
        self.diseno=diseno
        self.empresa_autos= Empresa_autos
        self.motor=motor
        self.velocidadmax= velocidadmax
        self.aceleracion= aceleracion
    def trasladar(self):
        pass
    def getEmpresa_autos(self):
        return self.Empresa_autos
    def setVelocidadmax(self,velocidadmax):
        self.velocidadmax +=velocidadmax