class Empresa_autos():
    def __init__(self,nombre, ubicacion, fundacion, dueno, cotizacion):
        self.nombre= nombre
        self.ubicacion= ubicacion
        self.fundacion= fundacion
        self.dueno= dueno
        self.cotizacion= cotizacion
    def vender(self):
        pass
    def getUbicacion(self):
        return self.ubicacion
    def setCotizacion(self,cotizacion):
        self.cotizacion += cotizacion