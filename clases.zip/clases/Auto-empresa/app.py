import auto
import empresa_autos
import os

diseno1 = os.sys.argv[1]
diseno2 = os.sys.argv[2]
empresa1 = os.sys.argv[3]

EMPRESA = empresa_autos.Empresa_autos(empresa1, "Suecia", "15 julio 1985", "mark ferrari", 13)
AC1 = auto.Auto(diseno1, EMPRESA, "12V", 225, 23)

print(AC1.trasladar(), "y", NOM)