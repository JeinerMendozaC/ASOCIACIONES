class Banco():
    def __init__(self,nombre, sede, propietario, fundacion, nro_cel):
        self.nombre=nombre
        self.sede= sede
        self.propietario=propietario
        self.fundacion= fundacion
        self.nro_cel= nro_cel
    def prestar(self):
        pass
    def getFundacion(self):
        return self.fundacion

    def guardar_dinero(self):
        pass