class Deuda():
    def __init__(self,monto,interes,tiempo,banco,tipo_interes):
        self.monto=monto
        self.interes= interes
        self.tiempo=tiempo
        self.banco= banco
        self.tipo_interes= tipo_interes
    def getInteres(self):
        self.interes
    def getBanco(self):
        return self.banco
    def setmonto(self,monto):
        self.monto +=monto