class Cantante():
    def __init__(self,nombre,nombre_artistico,edad,genero,nacionalidad):
        self.nombre=nombre
        self.nombre_artistico= nombre_artistico
        self.edad=edad
        self.genero= genero
        self.nacionalidad= nacionalidad
    def cantar(self):
        pass
    def getEdad(self):
        return self.edad
    def componer(self):
        pass