class Concierto():
    def __init__(self,pais,ciudad,nro_entradas,lugar,nombre):
        self.pais=pais
        self.ciudad= ciudad
        self.nro_entradas=nro_entradas
        self.lugar= lugar
        self.nombre= nombre

    def getCantante(self):
        return self.getCantante()
    def setGanancias(self, ganancias):
        self.ganncias += nro_entradas*costo
    def setNro_entradas(self,nro_entradas):
        self.nro_entradas +=nro_entradas