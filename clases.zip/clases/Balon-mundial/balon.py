class Balon():
    def __init__(self,nombre, diametro, peso, material, anho):
        self.nombre= nombre
        self.diametro= diametro
        self.peso = peso
        self.material= material
        self.anho= anho
    def trasladar(self):
        pass
    def getpeso(self):
        return self.peso
    def setDiametro(self,diametro):
        self.diametro += diametro