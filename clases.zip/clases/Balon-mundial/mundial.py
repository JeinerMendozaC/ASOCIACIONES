class Mundial():
    def __init__(self,pais, anho, campeon, balon, goles):
        self.pais= pais
        self.anho = anho
        self.campeon= campeon
        self.balon= balon
        self.goles= goles
    def recaudar(self):
        pass
    def getBalon(self):
        return self.Balon
    def setGoles(self, goles):
        self.goles += goles