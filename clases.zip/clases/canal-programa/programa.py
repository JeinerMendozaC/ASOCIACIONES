class Programa():
    def __init__(self,nombre,canal_tv,conductores,horarios,duracion):
        self.nombre=nombre
        self.canal_tv= canal_tv
        self.conductores=conductores
        self.horarios= horarios
        self.duracion= duracion

    def getCanal_tv(self):
        return self.canal_tv
    def getDuracion(self):
        return self.duracion
    def setHorario(self,horario):
        self.horarios +=horario