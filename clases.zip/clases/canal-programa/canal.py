class Canal():
    def __init__(self,nombre, fundacion, tipo, propietario, cotizacion):
        self.nombre=nombre
        self.fundacion= fundacion
        self.tipo=tipo
        self.propietario= propietario
        self.cotizacion= cotizacion
    def informar(self):
        pass
    def setCotizacion(self, cotizacion):
        return self.cotizacion += cotizacion

    def informar(self):
        pass