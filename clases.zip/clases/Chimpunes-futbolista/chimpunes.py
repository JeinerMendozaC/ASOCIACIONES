class Auto():
    def __init__(self,talla,diseno,precio,material,uso):
        self.talla=talla
        self.diseno= diseno
        self.precio=precio
        self.material= material
        self.uso= uso
    def cubrir(self):
        pass

    def brindar_agarre:(self):
        pass

    def evitar_lesiones(self):
        pass