class Futbolista():
    def __init__(self,nombre,dorsal,poscicio,pais,club):
        self.nombre=nombre
        self.dorsal= dorsal
        self.poscicio=poscicio
        self.pais= pais
        self.club= club
    def correr(self):
        pass
    def getChimpum(self):
        return self.getChimpum()

    def patear(self):
        pass